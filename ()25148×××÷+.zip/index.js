const { Telegraf } = require('telegraf');
const fetch = require('node-fetch');
const axios = require('axios');
const fs = require('fs');
const pino = require('pino');
const { Boom } = require('@hapi/boom');
const { default: makeWASocket, useMultiFileAuthState, DisconnectReason, fetchLatestWaWebVersion } = require('@whiskeysockets/baileys');

// ==========================
// KONFIGURASI DASAR
// ==========================
const BOT_TOKEN = '8323815702:AAFM3yaQWKj31N2n1lLetWBe6qzKp9En2F8';
const API_KEY = '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';
const BASE_URL = 'domain_base';
const ADMIN_ID = 8201382395;
const SESSION_NAME = './sessions'; // folder penyimpanan data WA
const bot = new Telegraf(BOT_TOKEN);

let waClient = null;
let waConnectionStatus = 'closed';
const userCooldowns = {}; // { userId: timestamp_end_cooldown }

// ==========================
// HELPER FUNCTION UMUM
// ==========================

function formatResult(data) {
  let out = '📨 *Hasil API:*\n';
  if (data.success !== undefined)
    out += `• Status: ${data.success ? '✅ Berhasil' : '❌ Gagal'}\n`;
  if (data.message) out += `• Pesan: ${data.message}\n`;
  if (data.nomor) out += `• Nomor: ${data.nomor}\n`;
  if (data.email) out += `• Email: ${data.email}\n`;
  if (data.subject) out += `• Subjek: ${data.subject}\n`;
  if (data.response) out += `• Respon: ${data.response}\n`;
  return out;
}

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

// ==========================
// FITUR PREMIUM USER
// ==========================
const premiumFile = './premium.json';
let premiumUsers = fs.existsSync(premiumFile)
  ? JSON.parse(fs.readFileSync(premiumFile))
  : [];

function savePremium() {
  fs.writeFileSync(premiumFile, JSON.stringify(premiumUsers, null, 2));
}

function isPremium(id) {
  return premiumUsers.includes(id);
}

// GANTI ID ADMIN DENGAN ID KAMU SENDIRI

// ➕ ADDPREM
bot.command('addprem', async (ctx) => {
  if (ctx.from.id !== ADMIN_ID)
    return ctx.reply('❌ Hanya admin yang bisa menambah premium.');

  // ambil id dari reply atau dari argumen
  const args = ctx.message.text.split(' ');
  let targetId;

  if (ctx.message.reply_to_message) {
    targetId = ctx.message.reply_to_message.from.id;
  } else if (args[1]) {
    targetId = parseInt(args[1]);
  }

  if (!targetId || isNaN(targetId))
    return ctx.reply('❌ Gunakan: /addprem <id> atau reply pesan user.');

  if (!premiumUsers.includes(targetId)) {
    premiumUsers.push(targetId);
    savePremium();
    ctx.reply(`✅ User ${targetId} ditambahkan ke daftar premium.`);
  } else {
    ctx.reply('⚠️ User sudah premium.');
  }
});

// ➖ DELPREM
bot.command('delprem', async (ctx) => {
  if (ctx.from.id !== ADMIN_ID)
    return ctx.reply('❌ Hanya admin yang bisa menghapus premium.');

  const args = ctx.message.text.split(' ');
  let targetId;

  if (ctx.message.reply_to_message) {
    targetId = ctx.message.reply_to_message.from.id;
  } else if (args[1]) {
    targetId = parseInt(args[1]);
  }

  if (!targetId || isNaN(targetId))
    return ctx.reply('❌ Gunakan: /delprem <id> atau reply pesan user.');

  if (premiumUsers.includes(targetId)) {
    premiumUsers = premiumUsers.filter(id => id !== targetId);
    savePremium();
    ctx.reply(`✅ User ${targetId} dihapus dari daftar premium.`);
  } else {
    ctx.reply('⚠️ User tidak ada di daftar premium.');
  }
});

// 📜 LISTPREM
bot.command('listprem', async (ctx) => {
  if (!premiumUsers.length) return ctx.reply('📭 Belum ada user premium.');
  const list = premiumUsers.map((id, i) => `${i + 1}. ${id}`).join('\n');
  ctx.reply(`💎 *Daftar Premium:*\n${list}`, { parse_mode: 'Markdown' });
});

// ==========================
// PROTEKSI PREMIUM UNTUK FITUR LAIN
// ==========================

// Middleware global (cek semua command selain /start dan fitur admin)
// Middleware global (cek semua command selain /start dan fitur admin)
bot.use(async (ctx, next) => {
  const isAdmin = ctx.from?.id === ADMIN_ID;
  const message = ctx.message?.text || "";
  const command = message.split(' ')[0].toLowerCase();

  // command bebas: start & admin
  const allowed = ['/start', '/addprem', '/delprem', '/listprem'];

  if (ctx.updateType === 'message' && command.startsWith('/')) {
    if (!allowed.includes(command) && !isAdmin && !isPremium(ctx.from.id)) {
      return ctx.reply('❌ Fitur ini hanya untuk user premium.\nHubungi admin untuk akses premium.');
    }
  }

  await next();
});
// ==========================
// WHATSAPP CLIENT (BAILEYS)
// ==========================

async function startWhatsAppClient() {
  console.log("🚀 Memulai koneksi WhatsApp...");

  // Ambil data sesi
  const { state, saveCreds } = await useMultiFileAuthState(SESSION_NAME);

  // Ambil versi terbaru WhatsApp Web
  const { version, isLatest } = await fetchLatestWaWebVersion();
  console.log(`📦 Versi WA Web: ${version.join('.')} (Latest: ${isLatest})`);

  // Buat koneksi WA
  waClient = makeWASocket({
    logger: pino({ level: 'silent' }),
    printQRInTerminal: false,
    auth: state,
    version,
    browser: ["Ubuntu", "Chrome", "20.0.00"]
  });

  // Simpan kredensial otomatis
  waClient.ev.on('creds.update', saveCreds);

  // Cek status koneksi
  waClient.ev.on('connection.update', (update) => {
    const { connection, lastDisconnect } = update;
    waConnectionStatus = connection;

    if (connection === 'close') {
      const reason = new Boom(lastDisconnect?.error)?.output?.statusCode;
      const shouldReconnect = reason !== DisconnectReason.loggedOut;
      console.log(`❌ Koneksi WA terputus. Reason: ${reason}`);

      if (shouldReconnect) {
        console.log("🔄 Reconnecting dalam 5 detik...");
        setTimeout(startWhatsAppClient, 5000);
      } else {
        console.log("🛑 Session logout. Hapus folder sessions untuk pairing ulang.");
        waClient = null;
      }

    } else if (connection === 'open') {
      console.log("✅ Berhasil tersambung ke WhatsApp!");
    }
  });
}

// Jalankan
startWhatsAppClient();

// ===========================
// HANDLE CEK BIO (FIXED)
// ===========================
async function handleBioCheck(ctx, numbersToCheck) {
  if (waConnectionStatus !== 'open')
    return ctx.reply("⚠️ WA belum konek, tunggu beberapa detik dan coba lagi.");
  if (numbersToCheck.length === 0)
    return ctx.reply("Nomornya mana, kakak?");

  await ctx.reply(`🔍 OKE👌, Kakak Ngecek ${numbersToCheck.length} Lagi Di Cek.`);

  let withBio = [], noBio = [], notRegistered = [];

  const jids = numbersToCheck.map(num => num.trim() + '@s.whatsapp.net');
  const existenceResults = await waClient.onWhatsApp(...jids);

  const registeredJids = [];
  existenceResults.forEach(res => {
    if (res.exists) registeredJids.push(res.jid);
    else notRegistered.push(res.jid.split('@')[0]);
  });

  const registeredNumbers = registeredJids.map(jid => jid.split('@')[0]);
  if (registeredNumbers.length > 0) {
    const batchSize = 15;
    for (let i = 0; i < registeredNumbers.length; i += batchSize) {
      const batch = registeredNumbers.slice(i, i + batchSize);
      const promises = batch.map(async (nomor) => {
        const jid = nomor.trim() + '@s.whatsapp.net';
        try {
          const statusResult = await waClient.fetchStatus(jid);
          let bioText = null, setAtText = null;
          if (Array.isArray(statusResult) && statusResult.length > 0) {
            const data = statusResult[0];
            if (data) {
              if (typeof data.status === 'string') bioText = data.status;
              else if (typeof data.status === 'object' && data.status !== null)
                bioText = data.status.text || data.status.status;
              setAtText = data.setAt || (data.status && data.status.setAt);
            }
          }

          if (bioText && bioText.trim() !== '') {
            withBio.push({ nomor, bio: bioText, date: setAtText });
          } else {
            noBio.push(nomor);
          }
        } catch {
          notRegistered.push(nomor.trim());
        }
      });
      await Promise.allSettled(promises);
      await sleep(500);
    }
  }

  // ==========================
  // FILE 1: NOMOR DENGAN BIO (MENARIK)
  // ==========================
  let fileWithBio = "📜 HASIL NOMOR DENGAN BIO\n";
  fileWithBio += "──────────────────────────────\n";
  fileWithBio += `📋 Total nomor dicek          : ${numbersToCheck.length}\n`;
  fileWithBio += `📱 Terdaftar dengan bio       : ${withBio.length}\n`;
  fileWithBio += `🚫 Tidak terdaftar            : ${notRegistered.length}\n\n`;

  if (withBio.length > 0) {
    fileWithBio += "──────────────────────────────\n";
    fileWithBio += "✨ DETAIL NOMOR DENGAN BIO ✨\n\n";
    withBio.forEach(item => {
      const date = new Date(item.date);
      const formatted = !isNaN(date)
        ? date.toLocaleString('id-ID')
        : 'Tanggal tidak diketahui';
      fileWithBio += `📌 ${item.nomor}\n📝 Bio      : ${item.bio}\n📅 Date     : ${formatted}\n\n`;
    });
  }

  // ==========================
  // FILE 2: NOMOR TANPA BIO (MENARIK)
  // ==========================
  let fileNoBio = "📭 HASIL NOMOR TANPA BIO\n";
  fileNoBio += "──────────────────────────────\n";
  fileNoBio += `📋 Total nomor dicek          : ${numbersToCheck.length}\n`;
  fileNoBio += `📱 Terdaftar tanpa bio        : ${noBio.length}\n`;
  fileNoBio += `🚫 Tidak terdaftar            : ${notRegistered.length}\n\n`;

  if (noBio.length > 0) {
    fileNoBio += "──────────────────────────────\n";
    fileNoBio += "⚡ LIST NOMOR TANPA BIO ⚡\n";
    fileNoBio += noBio.join('\n') + '\n';
  }

  // ==========================
  // TULIS DAN KIRIM FILE
  // ==========================
  const filePathWithBio = `./hasil_denganbio_${ctx.from.id}.txt`;
  const filePathNoBio = `./hasil_tanpabio_${ctx.from.id}.txt`;

  fs.writeFileSync(filePathWithBio, fileWithBio);
  fs.writeFileSync(filePathNoBio, fileNoBio);

  await ctx.replyWithMarkdown(`\`\`\`
🎉 ✅ 𝗦𝗰𝗮𝗻 𝗦𝗲𝗹𝗲𝘀𝗮𝗶, 𝗕𝗼𝘀𝗸𝘂𝘂! 🎉
━━━━━━━━━━━━━━━━━━━━━━
📊 𝗧𝗼𝘁𝗮𝗹 𝗡𝗼𝗺𝗼𝗿 𝗗𝗶𝗰𝗲𝗸      : ${numbersToCheck.length}
🌸 𝗧𝗲𝗿𝗱𝗮𝗳𝘁𝗮𝗿 𝗱𝗲𝗻𝗴𝗮𝗻 𝗕𝗶𝗼  : ${withBio.length}
📭 𝗧𝗲𝗿𝗱𝗮𝗳𝘁𝗮𝗿 𝘁𝗮𝗻𝗽𝗮 𝗕𝗶𝗼   : ${noBio.length}
🚫 𝗧𝗶𝗱𝗮𝗸 𝗧𝗲𝗿𝗱𝗮𝗳𝘁𝗮𝗿         : ${notRegistered.length}
━━━━━━━━━━━━━━━━━━━━━━
✨ Hasil sudah siap di file dan bisa diunduh di bawah ⬇️
💠 𝗙𝗶𝘅 𝗠𝗲𝗿𝗮𝗵 𝗡𝗲𝘄
\`\`\``);
  
  await ctx.replyWithDocument({ source: filePathWithBio }, { caption: "📄 Ringkasan & detail nomor dengan bio" });
  await ctx.replyWithDocument({ source: filePathNoBio }, { caption: "📄 Ringkasan & list nomor tanpa bio" });

  fs.unlinkSync(filePathWithBio);
  fs.unlinkSync(filePathNoBio);
}

// Helper
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ==========================
//  COMMANDS TELEGRAM
// ==========================
bot.command('pairing', async (ctx) => {
  const phoneNumber = ctx.message.text.split(' ')[1]?.replace(/[^0-9]/g, '');
  if (!phoneNumber)
    return ctx.reply("❌ Format salah!\nGunakan: `/pairing 628xxxx`", { parse_mode: 'Markdown' });
  if (!waClient)
    return ctx.reply("⚠️ Koneksi WA belum siap, tunggu bentar bos.");

  try {
    await ctx.reply("Otw minta kode pairing...");
    const code = await waClient.requestPairingCode(phoneNumber);
    await ctx.reply(`📲 Nih kodenya bos: *${code}*\n\nMasukin di WA kamu:\n*Tautkan Perangkat > Tautkan dengan nomor telepon*`,
      { parse_mode: 'Markdown' });
  } catch (e) {
    console.error(e);
    ctx.reply("❌ Gagal minta kode pairing, coba lagi nanti.");
  }
});

bot.command('cek', async (ctx) => {
  const nums = ctx.message.text.split(' ').slice(1).join(' ').match(/\d+/g) || [];
  await handleBioCheck(ctx, nums);
});


bot.on('document', async (ctx) => {
  const doc = ctx.message.document;
  const allowedTypes = ['text/plain', 'text/csv']; // Bisa ditambah

  if (!allowedTypes.includes(doc.mime_type)) {
    return ctx.reply("Filenya harus format .txt atau .csv ya bos!");
  }

  try {
    // Ambil link file dari Telegram
    const fileLink = await ctx.telegram.getFileLink(doc.file_id);

    // Ambil konten file sebagai arraybuffer (menghindari encoding error)
    const response = await axios.get(fileLink.href, { responseType: 'arraybuffer' });

    // Ubah buffer menjadi string (UTF-8)
    const data = Buffer.from(response.data, 'binary').toString('utf-8');

    // Ambil semua nomor dari file (hanya digit)
    const numbers = data.match(/\d+/g) || [];
    if (numbers.length === 0) return ctx.reply("❌ Tidak ditemukan nomor di file.");

    // Jalankan pengecekan bio otomatis
    await handleBioCheck(ctx, numbers);

  } catch (err) {
    console.error(err);
    ctx.reply("❌ Gagal membaca file, coba lagi bos.");
  }
});

// Helper: panggil API
async function callApi(endpoint, params = {}) {
  const url = new URL(BASE_URL + endpoint);
  params.apikey = API_KEY;
  Object.keys(params).forEach(k => url.searchParams.append(k, params[k]));
  const res = await fetch(url.toString());
  return res.json();
}

function startCooldown(ctx, userId, seconds = 200) {
  userCooldowns[userId] = Date.now() + seconds * 1000;
  let elapsed = 0;
  
  const frames = ['▱', '▰', '◈', '◇', '◆', '▣'];
  let frameIndex = 0;

  ctx.reply(
    `🧬 *[SYSTEM ONLINE]*\n` +
    `Initializing Cooldown Sequence...\n` +
    `Progress: [░░░░░░░░░░░░░░░░░░░░] 0%`,
    { parse_mode: 'Markdown' }
  ).then(message => {
    const interval = setInterval(async () => {
      elapsed++;
      const remaining = seconds - elapsed;
      const percent = Math.floor((elapsed / seconds) * 100);
      const filledBlocks = Math.floor((elapsed / seconds) * 20);
      const bar = '█'.repeat(filledBlocks) + '░'.repeat(20 - filledBlocks);
      const frame = frames[frameIndex % frames.length];
      frameIndex++;

      try {
        if (remaining > 0) {
          await ctx.telegram.editMessageText(
            ctx.chat.id,
            message.message_id,
            undefined,
            `\`\`\`⚙️ [𝗙𝗜𝗫 𝗠𝗘𝗥𝗔𝗛 𝗡𝗘𝗪]\n +
            Progress: [${bar}] ${percent}%\n +
            💠 𝗘𝗹𝗮𝗽𝘀𝗲𝗱: ${elapsed}s / ${seconds}s\n +
            💤 𝗠𝗼𝗱𝗲: Hyper Cooldown ${frame}\n +
            💬 𝗦𝘁𝗮𝘁𝘂𝘀: Stabilizing System...\`\`\``,
            { parse_mode: 'Markdown' }
          );
        } else {
          clearInterval(interval);

          const selesai = new Date();
          const jam = selesai.toLocaleTimeString('id-ID', { hour12: false });
          const tanggal = selesai.toLocaleDateString('id-ID', {
            day: '2-digit',
            month: 'long',
            year: 'numeric'
          });

          const sertifikat = `\`\`\`[𝗦𝗨𝗖𝗖𝗘𝗦𝗙𝗨𝗟𝗟 𝗕𝗔𝗡𝗗𝗜𝗡𝗚]
────────────────────
📅 Tanggal: ${tanggal}
🕓 Waktu: ${jam}
⏱ Durasi: ${seconds}s
💫 Status: ✅ Selesai & Tersinkronisasi

🧠 System Mode: Gen2 Interior - Cooldown Completed
👑 Authorized By: 𝗥𝗶𝗷𝗮𝗹𝗝𝗿
────────────────────
「✨ 𝗘𝗻𝗲𝗿𝗴𝘆 𝗦𝘁𝗮𝗯𝗶𝗹 • 𝗦𝘆𝘀𝘁𝗲𝗺 𝗔𝗺𝗮𝗻 ✨」
\`\`\``;

          await ctx.telegram.editMessageText(ctx.chat.id, message.message_id, undefined, sertifikat, {
            parse_mode: 'Markdown',
            reply_markup: {
              inline_keyboard: [
                [
                  { text: '🔁 Jalankan Ulang Sequence', callback_data: 'ulangCooldown' },
                  { text: '🏠 Dashboard', callback_data: 'menu' }
                ],
                [{ text: '⚙️ System Logs', callback_data: 'banding' }]
              ]
            }
          });
        }
      } catch (err) {
        clearInterval(interval);
        console.error('Cooldown update error:', err.message);
      }
    }, 1000);
  });
}

// ==========================
// DASHBOARD MENU KOMBINASI
// ==========================
function dashboardText() {
  return (
`\`\`\`
╭──(    𝙍𝙞𝙟𝙖𝙡 ☇ 𝙅𝙧    )
║ᨒ 𝙍𝙞𝙟𝙖𝙡 𝐗𝐱𝐗
│🎭 𝐍𝐚𝐦𝐞 : 𝙁𝙞𝙭 𝙈𝙚𝙧𝙖𝙝 𝙉𝙚𝙬
║▬▭▬▭▬▭▬▭▬▭
│🎭 𝐍𝐚𝐦𝐞 𝐒𝐜𝐫𝐢𝐩𝐭 : 𝙁𝙞𝙭 𝙈𝙚𝙧𝙖𝙝 𝘽𝙤𝙩
║🎭 𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 : 𝙍𝙞𝙟𝙖𝙡𝙅𝙧
│🎭 𝐕𝐞𝐫𝐬𝐢𝐨𝐧: 1.0
║🎭 𝐏𝐫𝐞𝐟𝐢𝐱 : 𝐓𝐞𝐥𝐞𝐠𝐫𝐚𝐦
│▬▭「 𝙁𝙞𝙭 𝙈𝙚𝙧𝙖𝙝🐉 」▭▬
║› © 𝙍𝙞𝙟𝙖𝙡𝙅𝙧
╰━━━━━━━━━━━━━━━━━━━⬣
 𝐬𝐢𝐥𝐚𝐡𝐤𝐚𝐧 𝐩𝐢𝐥𝐢𝐡 𝐦𝐞𝐧𝐮 𝐛𝐮𝐭𝐭𝐨𝐧 𝐝𝐢 𝐛𝐚𝐰𝐚𝐡\`\`\``
  );
}

function dashboardMenu() {
  return {
    parse_mode: 'Markdown',
    reply_markup: {
      inline_keyboard:[ 
          [
          { text: 'Mode Banding', callback_data: 'banding' },
          { text: 'Test Email', callback_data: 'testsend' }
        ],
        [{ text: 'Pairing & CekBio', callback_data: 'pairmenu' }],
        [{ text: 'Refresh Dashboard', callback_data: 'menu' }]
      ]
    }
  };
}

// 🎯 Command /start → kirim dashboard utama + musik
bot.start(async (ctx) => {
  const photoUrl = "https://files.catbox.moe/zwj2lp.jpg"; // Gambar dashboard
  const MUSIC_URL = "https://files.catbox.moe/6nuysw.mp3"; // Ganti dengan musik kamu

  // Kirim foto & teks utama
  await ctx.replyWithPhoto(
    { url: photoUrl },
    {
      caption: `\`\`\`
╭──(    𝙍𝙞𝙟𝙖𝙡 ☇ 𝙅𝙧    )
║ᨒ 𝙍𝙞𝙟𝙖𝙡 𝐗𝐱𝐗
│🎭 𝐍𝐚𝐦𝐞 : 𝙁𝙞𝙭 𝙈𝙚𝙧𝙖𝙝 𝙉𝙚𝙬
║▬▭▬▭▬▭▬▭▬▭
│🎭 𝐍𝐚𝐦𝐞 𝐒𝐜𝐫𝐢𝐩𝐭 : 𝙁𝙞𝙭 𝙈𝙚𝙧𝙖𝙝 𝘽𝙤𝙩
║🎭 𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 : 𝙍𝙞𝙟𝙖𝙡𝙅𝙧
│🎭 𝐕𝐞𝐫𝐬𝐢𝐨𝐧: 1.0
║🎭 𝐏𝐫𝐞𝐟𝐢𝐱 : 𝐓𝐞𝐥𝐞𝐠𝐫𝐚𝐦
│▬▭「 𝙁𝙞𝙭 𝙈𝙚𝙧𝙖𝙝🐉 」▭▬
║› © 𝙍𝙞𝙟𝙖𝙡𝙅𝙧
╰━━━━━━━━━━━━━━━━━━━⬣
 𝐬𝐢𝐥𝐚𝐡𝐤𝐚𝐧 𝐩𝐢𝐥𝐢𝐡 𝐦𝐞𝐧𝐮 𝐛𝐮𝐭𝐭𝐨𝐧 𝐝𝐢 𝐛𝐚𝐰𝐚𝐡\`\`\``,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [
            { text: "Mode Banding", callback_data: "banding" },
            { text: "Test Email", callback_data: "testsend" },
          ],
          [{ text: "Pairing & CekBio", callback_data: "pairmenu" }],
          [{ text: "Refresh Dashboard", callback_data: "menu" }],
        ],
      },
    }
  );

  // 🎵 Kirim musik hanya di awal (message pertama)
  await ctx.replyWithAudio(
    { url: MUSIC_URL },
    { caption: "ortulu mati" }
  );
});

// Handler tombol utama dashboard
bot.on('callback_query', async (ctx) => {
  const action = ctx.callbackQuery.data;
  const msgId = ctx.callbackQuery.message.message_id;
  const chatId = ctx.callbackQuery.message.chat.id;

  try {
    // 🏠 DASHBOARD UTAMA
    if (action === 'menu') {
      await ctx.telegram.editMessageCaption(
        chatId,
        msgId,
        undefined,
        dashboardText(),
        dashboardMenu()
      );
      return;
    }

    // ⚡ STATUS SERVER
    if (action === 'status') {
      const data = await callApi('/status');

      const statusText = `
╭─┈⚙️ *STATUS SERVER*
│ 👑 Owner : *${data.owner || 'Unknown'}*
│ 📦 Total Email : *${data.total_email}*
│ 🟢 Connect : *${data.connect}*
│ 🔴 Disconnect : *${data.disconnect}*
│ 🚀 Status : *${data.message || 'Service aktif'}*
╰───────────────────────
🏠 *Kembali ke Dashboard*
`.trim();

      await ctx.telegram.editMessageCaption(chatId, msgId, undefined, statusText, {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [{ text: '🏠 Dashboard', callback_data: 'menu' }],
            [{ text: '🔄 Refresh', callback_data: 'status' }]
          ]
        }
      });
      return;
    }

    // 📲 MODE BANDING
    if (action === 'banding') {
      await ctx.telegram.editMessageCaption(
        chatId,
        msgId,
        undefined,
        `\`\`\`╭─┈📲 MODE BANDING
          │ Gunakan format berikut untuk cek nomor:
          │\n' +
          │ /banding <nomor> 
          │ _Contoh:_ /banding 628123456789
          │
          │ 🔹 Cek cepat status nomor WhatsApp (Fix Merah 🔴)
          '╰───────────────────────
          '🏠 *Kembali ke Dashboard*\`\`\``,
        {
          parse_mode: 'Markdown',
          reply_markup: {
            inline_keyboard: [[{ text: '🏠 Dashboard', callback_data: 'menu' }]]
          }
        }
      );
      return;
    }

    // ✉️ TEST EMAIL
    if (action === 'testsend') {
      await ctx.telegram.editMessageCaption(
        chatId,
        msgId,
        undefined,
        `\`\`\`╭─┈✉️ TEST KIRIM EMAIL
          │ Gunakan format berikut:
          │
          │ /testsend <email> <nomor>
          │
          │ Contoh: /testsend user@mail.com 628123456789
          │
          │ 🔹 Untuk menguji koneksi & pengiriman SMTP
          '╰───────────────────────
          '🏠 *Kembali ke Dashboard*\`\`\``,
        {
          parse_mode: 'Markdown',
          reply_markup: {
            inline_keyboard: [[{ text: '🏠 Dashboard', callback_data: 'menu' }]]
          }
        }
      );
      return;
    }

    // 🧩 PAIRING & CEKBIO
    if (action === 'pairmenu') {
      await ctx.telegram.editMessageCaption(
        chatId,
        msgId,
        undefined,
        `\`\`\`╭─┈🧩 PAIRING & CEKBIO
          │ Perintah tersedia:
          │
          │ /pairing 628xxxxxxx
          │ /cek 628xxxxxxx
          │
          │ 📄 Kirim *file .txt* / *.csv* untuk cek massal.
          │ 🔹 Otomatis pairing & ambil bio nomor WA.
          ╰───────────────────────\n' +
          🏠 *Kembali ke Dashboard*\`\`\``,
        {
          parse_mode: 'Markdown',
          reply_markup: {
            inline_keyboard: [[{ text: '🏠 Dashboard', callback_data: 'menu' }]]
          }
        }
      );
      return;
    }

  } catch (err) {
    console.error('Callback Error:', err);

    // ✅ perbaikan: tambahkan backtick agar template string valid
    await ctx.answerCbQuery(`❌ Error: ${err.message}`, { show_alert: true });
  }

  await ctx.answerCbQuery();
});

// ⚙️ STATUS SERVER
bot.command('status', async (ctx) => {
  try {
    const data = await callApi('/status');

    const text = `
╭─┈⚙️ *STATUS SERVER*
│ 👑 Owner : *${data.owner || 'Unknown'}*
│ 📦 Total Email : *${data.total_email}*
│ 🟢 Connect : *${data.connect}*
│ 🔴 Disconnect : *${data.disconnect}*
│ 🚀 Status : *${data.message || 'Service aktif'}*
╰───────────────────────
💠 *System Active • Gen-2 Interior Mode*`;

    await ctx.replyWithMarkdown(text, { disable_web_page_preview: true });
  } catch (err) {
    console.error(err);
    await ctx.reply(`❌ *Error:* ${err.message}`, { parse_mode: 'Markdown' });
  }
});


// ✉️ TEST EMAIL
bot.command('testsend', async (ctx) => {
  const parts = ctx.message.text.split(' ');

  if (!parts[1]) {
    return ctx.replyWithMarkdown(
      '⚠️ *Format Salah!*\nGunakan:\n`/testsend <email> <pesan>`'
    );
  }

  const email = parts[1];
  const pesan = parts.slice(2).join(' ');

  if (!pesan) {
    return ctx.replyWithMarkdown(
      '⚠️ Masukkan pesan yang ingin dikirim.\n\n📌 *Contoh:*\n`/testsend email@gmail.com Halo tim WhatsApp, saya ingin banding akun saya.`'
    );
  }

  try {
    const data = await callApi('/testsend', { email, pesan });

    const resultText = `
╭─┈✉️ *TEST EMAIL BERHASIL*
│ 📮 Email : *${email}*
│ 💬 Pesan : _${pesan}_
│ ✅ Status : *${data.status || 'Terkirim'}*
╰───────────────────────
💠 *Gen-2 Interior Connection Stable*`;

    ctx.replyWithMarkdown(resultText);
  } catch (err) {
    ctx.reply(`❌ Error: ${err.message}`);
  }
});


// 📲 MODE BANDING (COOLDOWN 60s)
bot.command('banding', async (ctx) => {
  const userId = ctx.from.id;
  const now = Date.now();

  const args = ctx.message.text.split(' ').slice(1);
  const nomor = args[0]?.trim();

  if (!nomor) {
    return ctx.replyWithMarkdown(
            '⚠️ Kirim nomor setelah command.\n\n📌 *Contoh:*\n`/banding 6281234567890`'
    );
  }

  if (!/^\d{8,15}$/.test(nomor)) {
    return ctx.reply('❌ Nomor tidak valid. Gunakan hanya angka tanpa spasi atau simbol.');
  }

  // COOLDOWN
  const cooldownEnd = userCooldowns[userId] || 0;
  if (now < cooldownEnd) {
    const wait = Math.ceil((cooldownEnd - now) / 1000);
    return ctx.reply(`🕓 Tunggu ${wait}s sebelum bisa cek nomor lagi.`);
  }

  // MULAI COOLDOWN
  startCooldown(ctx, userId, 60);

  try {
    await ctx.replyWithMarkdown(`🔍 *Memeriksa nomor:* \`${nomor}\`\n🧠 Mode: *Gen-2 Banding System*`);
    const data = await callApi('/banding', { nomor });

    const resultText = `\`\`\`
╭─┈📲 𝗛𝗔𝗦𝗜𝗟 𝗣𝗘𝗡𝗚𝗘𝗖𝗘𝗞𝗔𝗡 𝗡𝗢𝗠𝗢𝗥
│ 🔢 Nomor : ${nomor}
│ 📊 Status : ${data.status || 'Unknown'}
│ 💬 Info : _${data.message || 'Nomor berhasil dicek'}
╰───────────────────────
💠 𝗙𝗶𝘅 𝗠𝗲𝗿𝗮𝗵 𝗡𝗲𝘄\`\`\``;

    await ctx.replyWithMarkdown(resultText);
  } catch (err) {
    await ctx.reply(`❌ Terjadi kesalahan: ${err.message}`);
  }
});

bot.launch().then(() => console.log('🤖 BOT TELE AKTIF | WA CLIENT JALAN ✅'));